﻿using System.Net;
using System.Threading;
using System.Text.Json;


namespace FinalTestSample
{
    class data
    {

    }

    public class Global
    {
        public static Mutex mut;

        

        public static void ContextHandle(object httplistener)
        {
            mut.WaitOne();
            HttpListener listener = (HttpListener)httplistener;
            HttpListenerContext context = listener.GetContext();
            mut.ReleaseMutex();

            //사용자의 입력을 받고 출력을 한다.


            //---------------------------
            //여기부턴 예제입니다.

            HttpListenerRequest request = context.Request;
            HttpListenerResponse response = context.Response;
            response.AddHeader("Access-Control-Allow-Origin", "*");
            Stream body = request.InputStream;
            System.Text.Encoding encoding = request.ContentEncoding;
            System.IO.StreamReader reader = new System.IO.StreamReader(body, encoding);

            string rawurl = request.RawUrl;
            string httpmethod = request.HttpMethod;

            
            

            string result = "";

            result += string.Format("httpmethod = {0}\r\n", httpmethod);
            result += string.Format("rawurl = {0}\r\n", rawurl);
            System.Console.WriteLine(result);


            Message a = new Message();
            string responseString = JsonSerializer.Serialize(a);
            System.Console.WriteLine(responseString);
            byte[] buffer = System.Text.Encoding.UTF8.GetBytes(responseString);
            response.OutputStream.Write(buffer, 0, buffer.Length);
            response.OutputStream.Close();

            //----------------------------요기까지
        }
    }

    public class ServerLoop
    {
        HttpListener _listener;
        string _address;

        public ServerLoop(string address, string port)
        {
            _listener = new HttpListener();
            _address = "http://127.0.0.1" + ":" + port + "/";

            Global.mut = new Mutex();
            Global.mut.ReleaseMutex();
        }

        public void RestartLoop()
        {
            _listener = new HttpListener();
            Global.mut.ReleaseMutex();
        }

        

        public void AddRestAPI(string apiName)
        {
            _listener.Prefixes.Add(_address + apiName + "/");
        }
        public void Run()
        {
            _listener.Start();
            Console.WriteLine("Listening...");


            while (true)
            {
                Global.mut.WaitOne();
                Thread t = new Thread(new ParameterizedThreadStart(Global.ContextHandle));
                t.Start(_listener);
                Global.mut.ReleaseMutex();
            }
        }

        public void Close()
        {
            _listener.Stop();
        }

       

        void EndLoop()
        {
            if (_listener != null)
            {
                _listener.Stop();
                _listener.Close();
            }
        }
    }



    public class Program
    {
        public static int Main()
        {
            FileLogger fLog = new FileLogger("Log");

            //Log type 종류
            //<Exception>
            //<Debug>
            //<Record>            
            fLog.Write("Debug","I hate life.");

            ServerLoop server = new ServerLoop("http://127.0.0.1","3000");
            server.AddRestAPI("GodDamnChatService");
           
            server.Run();



            return 0;
        }
    }
}