﻿using System;
using System.IO;
using System.Text;
using System.Net;
using System.Threading.Tasks;

namespace sns_server
{
    class Program
    {
        public static void Main(string[] args)
        {
            // url 만들기 
            HttpListener listener = new HttpListener();
            listener.Prefixes.Add("http://127.0.0.1:3000/Got/"); // rest api호출
            // Prefixes 여기에 여러개 넣자! -> 현재 접속한 사람을 알 수 있다. 
            // 웹 소켓 내용 수정! -> 메세지, 사진, 현재 접속자 등의 작업을 하기 위해 필요
            // 정보 보내기는 json으로 (검색: c# json)
            // 클라에서 받은 데이터를 key값으로 나 이거 가져올거야!! -> 화면에 value 값 출력 

            listener.Start(); // 서버 열림 
            Console.WriteLine("Listening.......");

            while(true)
            {
                // context: 바인딩(그리기)이 들어가 있다.
                HttpListenerContext context = listener.GetContext(); // HttpListenerContext: rest api호출 받음, 요청, 응답에 대한 객체(정보)
                HttpListenerRequest request = context.Request; // 요청 get(리소스와 비교)
                                                               // 클라가 서버한테 보낸 정보가 request에 들어있음
                HttpListenerResponse response = context.Response; // 클라한테 응답(보내기) post

                // 데이터 처리
                // stream: 데이터가 끊기지 않고 연속적으로 데이터가 전송되는 것
                Stream body = request.InputStream; // 클라한테 받아온 데이터
                // InputStream: 클라한테 받은 데이터(바이트) 읽기
                System.Text.Encoding encoding = request.ContentEncoding; // 인코딩 초기화? 지정?
                // ContentEncoding:
                // encoding: 문자를 컴퓨터의 언어로 변환
                System.IO.StreamReader reader = new System.IO.StreamReader(body, encoding);
                // 지정된 stream값을 지정된 인코딩을 사용하여 StreamReader클래스 초기화
                
                string responseString = null;
                // 로그인 관연 코드 필요 
                // 로그인 http
                // 1. post로 로그인 데이터 보내기 
                // request로 로그인 정보 받기 -> 동일한지 확인 
                // 2. get(json)으로 로그인 상태 확인 y: 로그인 완료 n: 다시 로그인 ㄱㄱ
                // 1,2는 다른 api로 받아오기  http는 한번만 보내기 때문에 다른 api필요


                // if 로그인 정보 동일? 
                // y: string responseString = "로그인 성공"; 클라: 다른 페이지로 이동하는 코드 구현
                // (else) n: string responseString = "다시 로그인 ㄱㄱ"; 클라: 경고창 띄우기_alert, 초기화
                System.Console.WriteLine("1. request.ContentEncoding: " + request.ContentEncoding);

                string str = reader.ReadToEnd();
                // 입력값 2개 구분
                string[] loginInfor = str.Split("&");
                System.Console.WriteLine("1. reader: " + reader);
                System.Console.WriteLine("2. s: " + str);
                System.Console.WriteLine("3. loginInfor: " + loginInfor);
                System.Console.WriteLine("3. loginInfor[0]: " + loginInfor[0]);
                System.Console.WriteLine("4. loginInfor[1]: " + loginInfor[1]);

                string studentNumStr = loginInfor[0];
                string NickNameStr = loginInfor[1];

                string[] studentNum = studentNumStr.Split("=");
                string[] NickName = NickNameStr.Split("=");

                System.Console.WriteLine("5. studentNum[1]: " + studentNum[1]);
                System.Console.WriteLine("6. NickName[1]: " + NickName[1]);

                if (studentNum[1] == "202027019")
                {
                    responseString =
                    "<html>" +
                    "<head>" +
                    "<meta charset = 'UTF-8'>" +
                    "</head>" +
                    "<body>" +
                    "<h1>" +
                     NickName[1] +
                    "로그인 성공하셨습니다!" +
                    "</h1>" +
                    "</body>" +
                    "</html>";
                }
                else
                {
                    responseString =
                    "<html>" +
                    "<head>" +
                    "<meta charset = 'UTF-8'>" +
                    "</head>" +
                    "<body>" +
                    "<h1>" +
                    NickName[1] +
                    "! 다시 로그인하세요! " +
                    "</h1>" +
                    "</body>" +
                    "</html>";
                }

                System.Console.WriteLine("3. responseString: "+responseString);
                // POST 데이터 전송
                byte[] buffer = System.Text.Encoding.UTF8.GetBytes(responseString); // 바이트 -> UTF8 로 변환
                response.OutputStream.Write(buffer, 0, buffer.Length); // 응답 내용을 처음(0)부터 버퍼 길이만큼 보낸다.
                response.OutputStream.Close(); // 다 썼으니까 닫아! 
            }

            listener.Stop(); // 그만 들어


            // 메세지 관련 코드 구현
            // 웹 소켓 내용 수정! -> 메세지, 사진, 현재 접속자 등의 작업을 하기 위해 필요
            // 정보 보내기는 json으로 (검색: c# json)
            // 클라에서 받은 데이터를 key값으로 나 이거 가져올거야!! -> 화면에 value 값 출력 
        }
    }
}
